"""ROS2 nodes for object detection"""
