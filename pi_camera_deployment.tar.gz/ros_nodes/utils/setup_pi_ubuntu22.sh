#!/bin/bash

# Ubuntu 22.04 optimized setup script for Raspberry Pi Zero 2 W camera nodes
# ROS2 Humble + Native Ubuntu 22.04 packages
# Usage: ./setup_pi_ubuntu22.sh [camera_type] [pi_number]
# Example: ./setup_pi_ubuntu22.sh v20 1
# Example: ./setup_pi_ubuntu22.sh v21 2

set -e  # Exit on any error

CAMERA_TYPE=${1:-"v21"}
PI_NUMBER=${2:-"1"}

# Validate camera type
if [[ ! "$CAMERA_TYPE" =~ ^(v20|v21|ai)$ ]]; then
    echo "ERROR: Invalid camera type '$CAMERA_TYPE'"
    echo "Supported types: v20, v21, ai"
    exit 1
fi

echo "=========================================="
echo "Ubuntu 22.04 Pi Zero 2W Camera Setup"
echo "Camera: $CAMERA_TYPE, Pi #$PI_NUMBER"
echo "=========================================="

# Check Ubuntu version
if ! lsb_release -c | grep -q jammy; then
    echo "WARNING: This script is optimized for Ubuntu 22.04 (Jammy)"
    echo "Current version: $(lsb_release -d | cut -d: -f2 | xargs)"
fi

# Update system
echo "[1/9] Updating system..."
sudo apt update && sudo apt upgrade -y

# Enable universe repository (needed for some packages)
echo "[2/9] Enabling universe repository..."
sudo add-apt-repository universe -y

# Add ROS2 repository (Ubuntu 22.04 Jammy)
echo "[3/9] Adding ROS2 repository..."
sudo apt install -y curl gnupg lsb-release
sudo curl -sSL https://raw.githubusercontent.com/ros/rosdistro/master/ros.key -o /usr/share/keyrings/ros-archive-keyring.gpg
echo "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/ros-archive-keyring.gpg] http://packages.ros.org/ros2/ubuntu jammy main" | sudo tee /etc/apt/sources.list.d/ros2.list > /dev/null
sudo apt update

# Install ROS2 Humble (minimal, Ubuntu packages)
echo "[4/9] Installing ROS2 Humble (5-10 minutes)..."
sudo apt install -y \
    ros-humble-ros-base \
    ros-humble-cv-bridge \
    ros-humble-image-transport \
    ros-humble-rmw-cyclonedds-cpp \
    python3-colcon-common-extensions \
    python3-rosdep

# Initialize rosdep
echo "[5/9] Initializing rosdep..."
if [ ! -f /etc/ros/rosdep/sources.list.d/20-default.list ]; then
    sudo rosdep init
fi
rosdep update

# Install camera support (Ubuntu packages)
echo "[6/9] Installing camera support..."
sudo apt install -y \
    libcamera-apps \
    libcamera-dev \
    libcamera-tools \
    python3-picamera2 \
    python3-opencv \
    python3-yaml \
    python3-pip \
    v4l-utils

# Note: Camera publisher automatically detects and uses available camera interfaces
# on Ubuntu 22.04 (libcamera, V4L2, etc.)

# Configure camera permissions
echo "[7/9] Configuring camera..."
sudo usermod -aG video $USER

# Test camera (Ubuntu-specific)
echo "[8/9] Testing camera detection..."
CAMERA_FOUND=false
if command -v libcamera-hello &> /dev/null; then
    if libcamera-hello --list-cameras 2>/dev/null | grep -q "Available cameras\|Raspberry Pi Camera"; then
        echo "[OK] Camera detected via libcamera"
        CAMERA_FOUND=true
    fi
fi

if ! $CAMERA_FOUND && command -v v4l2-ctl &> /dev/null; then
    if v4l2-ctl --list-devices 2>/dev/null | grep -q "Camera\|unicam"; then
        echo "[OK] Camera detected via v4l2"
        CAMERA_FOUND=true
    fi
fi

if ! $CAMERA_FOUND; then
    echo "[WARNING] Camera not detected - check connection and run: sudo raspi-config"
fi

# Install AI dependencies if needed
if [ "$CAMERA_TYPE" = "ai" ]; then
    echo "[8.5/9] Installing AI dependencies..."
    # Use Ubuntu's pip with break-system-packages for AI packages
    pip3 install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cpu --break-system-packages
    pip3 install ultralytics --break-system-packages
    echo "[OK] AI dependencies installed"
fi

# Create workspace
echo "[9/9] Setting up workspace..."
mkdir -p ~/ros2_camera_ws/src

# Copy project files
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"

if [ -d "$PROJECT_ROOT/ros_nodes" ]; then
    cp -r "$PROJECT_ROOT" ~/ros2_camera_ws/src/urc-Espresso-2026
    echo "[OK] Project copied to workspace"
else
    echo "[WARNING] Project not found - copy manually to ~/ros2_camera_ws/src/urc-Espresso-2026"
fi

# Configure CycloneDDS
echo "[9.5/9] Configuring networking..."
sudo mkdir -p /etc/cyclonedds
sudo tee /etc/cyclonedds/config.xml > /dev/null <<'EOF'
<?xml version="1.0" encoding="UTF-8"?>
<CycloneDDS xmlns="https://cdds.io/config">
  <Domain id="42">
    <General>
      <NetworkInterfaceAddress>auto</NetworkInterfaceAddress>
      <MaxMessageSize>65536</MaxMessageSize>
    </General>
    <Discovery>
      <ParticipantIndex>auto</ParticipantIndex>
      <MaxAutoParticipantIndex>100</MaxAutoParticipantIndex>
    </Discovery>
    <Internal>
      <LeaseDuration>10s</LeaseDuration>
    </Internal>
  </Domain>
</CycloneDDS>
EOF

# Create systemd service
echo "[9.8/9] Creating auto-start service..."

if [ "$CAMERA_TYPE" = "v20" ] || [ "$CAMERA_TYPE" = "v21" ]; then
    SERVICE_NAME="camera-pi$PI_NUMBER"
    EXEC_CMD="python3 ~/ros2_camera_ws/src/urc-Espresso-2026/ros_nodes/cameras/pi_zero_2_w/camera_publisher/camera_publisher_node.py --pi-number $PI_NUMBER --camera-type $CAMERA_TYPE"
else
    SERVICE_NAME="ai-camera"
    EXEC_CMD="python3 ~/ros2_camera_ws/src/urc-Espresso-2026/ros_nodes/cameras/pi_zero_2_w/ai_camera_publisher/ai_camera_detector_node.py"
fi

sudo tee /etc/systemd/system/$SERVICE_NAME.service > /dev/null <<EOF
[Unit]
Description=ROS2 Camera Publisher ($CAMERA_TYPE) - Ubuntu 22.04
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=$USER
WorkingDirectory=/home/$USER/ros2_camera_ws
Environment="ROS_DOMAIN_ID=42"
Environment="RMW_IMPLEMENTATION=rmw_cyclonedds_cpp"
Environment="CYCLONEDDS_URI=file:///etc/cyclonedds/config.xml"
Environment="PYTHONPATH=/home/$USER/ros2_camera_ws/src/urc-Espresso-2026"
Environment="CAMERA_TYPE=$CAMERA_TYPE"
ExecStart=/bin/bash -c 'source /opt/ros/humble/setup.bash && export PYTHONPATH=/home/$USER/ros2_camera_ws/src/urc-Espresso-2026:\$PYTHONPATH && $EXEC_CMD'
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF

# Enable service
sudo systemctl daemon-reload
sudo systemctl enable $SERVICE_NAME.service

# Setup environment in .bashrc
echo "" >> ~/.bashrc
echo "# Ubuntu 22.04 ROS2 Camera Setup" >> ~/.bashrc
echo "source /opt/ros/humble/setup.bash" >> ~/.bashrc
echo "export ROS_DOMAIN_ID=42" >> ~/.bashrc
echo "export RMW_IMPLEMENTATION=rmw_cyclonedds_cpp" >> ~/.bashrc
echo "export CYCLONEDDS_URI=file:///etc/cyclonedds/config.xml" >> ~/.bashrc

# Set hostname
sudo hostnamectl set-hostname "pi-$CAMERA_TYPE-$PI_NUMBER"

echo ""
echo "=========================================="
echo "Ubuntu 22.04 Setup Complete!"
echo "=========================================="
echo ""
echo "Hostname: $(hostname)"
echo "Service: $SERVICE_NAME"
echo "ROS2: Humble (Ubuntu 22.04 packages)"
echo "Camera: $CAMERA_TYPE on Pi #$PI_NUMBER"
echo ""
echo "REBOOT NOW: sudo reboot"
echo ""
echo "After reboot:"
echo "  Camera auto-starts with service: $SERVICE_NAME"
echo "  Check status: systemctl status $SERVICE_NAME"
echo "  View logs: journalctl -u $SERVICE_NAME -f"
echo "  Test topics: ros2 topic list | grep camera"
echo ""
echo "Environment loaded automatically on login."
echo "=========================================="
