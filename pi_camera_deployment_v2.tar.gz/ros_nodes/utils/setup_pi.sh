#!/bin/bash

# Setup script for Raspberry Pi Zero 2 W camera nodes
# Usage: ./setup_pi.sh [camera_type] [pi_number]
# Example: ./setup_pi.sh v20 1
# Example: ./setup_pi.sh v21 2
# Example: ./setup_pi.sh ai

set -e  # Exit on any error

# Fix locale warning
export LC_ALL=C

CAMERA_TYPE=${1:-"v21"}
PI_NUMBER=${2:-"1"}

# Validate camera type
if [[ ! "$CAMERA_TYPE" =~ ^(v20|v21|ai)$ ]]; then
    echo "ERROR: Invalid camera type '$CAMERA_TYPE'"
    echo "Supported types: v20, v21, ai"
    exit 1
fi
LOG_FILE="$HOME/pi-camera-setup.log"

# Setup logging
exec 1> >(tee -a "$LOG_FILE")
exec 2>&1

echo "=========================================="
echo "Pi Zero 2W Camera Node Setup"
echo "Date: $(date)"
echo "Camera Type: $CAMERA_TYPE"
echo "Pi Number: $PI_NUMBER"
echo "=========================================="

# Validation function
validate_step() {
    if [ $? -eq 0 ]; then
        echo "[OK] $1"
    else
        echo "[FAIL] $1"
        exit 1
    fi
}

# Check system resources
echo "Checking system resources..."
TOTAL_MEM=$(free -m | awk '/^Mem:/{print $2}')
TOTAL_SWAP=$(free -m | awk '/^Swap:/{print $2}')
echo "RAM: ${TOTAL_MEM}MB, Swap: ${TOTAL_SWAP}MB"

if [ "$TOTAL_MEM" -lt 400 ]; then
    echo "[WARNING] Low RAM detected. This installation may be slow."
fi

if [ "$TOTAL_SWAP" -lt 300 ]; then
    echo "[WARNING] Insufficient swap space. Recommend at least 400MB swap for ROS2 installation."
    echo "The script will configure swap automatically in the next step."
fi

# Fix apt-listchanges issues before any apt operations
echo "Checking apt configuration..."
if [ -f /etc/apt/apt.conf.d/20listchanges ]; then
    if ! command -v apt-listchanges &> /dev/null; then
        echo "apt-listchanges not installed but configured, disabling it..."
        sudo mv /etc/apt/apt.conf.d/20listchanges /etc/apt/apt.conf.d/20listchanges.backup 2>/dev/null || true
    fi
fi

# Update system
echo "Updating system packages..."
sudo apt update && sudo apt upgrade -y
validate_step "System update"

# Configure swap for Pi Zero 2W (512MB RAM constraint)
echo "Configuring swap space for memory-constrained Pi Zero 2W..."

# Check if swap is already configured
if swapon --show | grep -q .; then
    echo "Swap already configured:"
    swapon --show
    echo "Skipping swap configuration..."
else
    if command -v dphys-swapfile &> /dev/null; then
        # Traditional Raspberry Pi OS
        sudo dphys-swapfile swapoff 2>/dev/null || true
        sudo sed -i 's/CONF_SWAPSIZE=.*/CONF_SWAPSIZE=2048/' /etc/dphys-swapfile
        sudo dphys-swapfile setup
        sudo dphys-swapfile swapon
        echo "Swap configured using dphys-swapfile (2GB)"
    elif [ -f /etc/systemd/zram-generator.conf ]; then
        # Newer systems with zram
        sudo tee /etc/systemd/zram-generator.conf > /dev/null <<EOF
[zram0]
zram-size = min(ram, 2048)
compression-algorithm = zstd
EOF
        sudo systemctl daemon-reload
        sudo systemctl restart systemd-zram-setup@zram0.service 2>/dev/null || true
        echo "Swap configured using zram (2GB)"
    else
        # Manual swap file creation
        echo "Creating manual swap file..."
        if [ -f /swapfile ]; then
            echo "Swapfile exists, checking if it's in use..."
            if sudo swapoff /swapfile 2>/dev/null; then
                echo "Disabled existing swapfile"
            fi
            sudo rm -f /swapfile
        fi
        sudo fallocate -l 2G /swapfile 2>/dev/null || sudo dd if=/dev/zero of=/swapfile bs=1M count=2048 status=none
        sudo chmod 600 /swapfile
        sudo mkswap /swapfile >/dev/null
        sudo swapon /swapfile
        # Add to fstab if not already present
        if ! grep -q '/swapfile' /etc/fstab; then
            echo '/swapfile none swap sw 0 0' | sudo tee -a /etc/fstab >/dev/null
        fi
        echo "Swap file created manually (2GB)"
    fi
fi
validate_step "Swap configuration"

# Install system dependencies
echo "Installing camera and system dependencies..."
# Ensure apt-listchanges is disabled for this installation
if [ -f /etc/apt/apt.conf.d/20listchanges ]; then
    echo "Disabling apt-listchanges for package installation..."
    sudo mv /etc/apt/apt.conf.d/20listchanges /etc/apt/apt.conf.d/20listchanges.backup 2>/dev/null || true
fi
sudo apt install -y v4l-utils libcamera-apps libcamera-dev python3-pip
validate_step "System dependencies"

# Configure camera permissions
echo "Configuring camera permissions..."
sudo usermod -a -G video $USER
validate_step "Camera permissions (added user to video group)"

# Test camera detection
echo "Detecting camera..."
CAMERA_DETECTED=false
if command -v vcgencmd &> /dev/null; then
    if vcgencmd get_camera | grep -q "detected=1"; then
        echo "[OK] Camera detected via vcgencmd"
        CAMERA_DETECTED=true
    fi
elif command -v v4l2-ctl &> /dev/null; then
    if v4l2-ctl --list-devices | grep -q "Camera\|camera\|Camera"; then
        echo "[OK] Camera detected via v4l2"
        CAMERA_DETECTED=true
    fi
fi

if [ "$CAMERA_DETECTED" = false ]; then
    echo "[WARNING] Camera not detected!"
    echo "Please check:"
    echo "  1. Camera cable connection"
    if command -v raspi-config &> /dev/null; then
        echo "  2. Enable camera: sudo raspi-config -> Interface Options -> Camera -> Enable"
    else
        echo "  2. Check camera permissions: sudo usermod -a -G video $USER"
    fi
    echo "  3. Reboot and run this script again"
    read -p "Continue anyway? (y/N): " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        exit 1
    fi
fi

# Test camera with libcamera
echo "Testing camera with libcamera-hello..."
timeout 5s libcamera-hello --nopreview || echo "[WARNING] Camera test timed out or failed"

# Install Miniforge for ARM64
echo "Installing Miniforge (includes conda + mamba)..."
cd /tmp
rm -f Miniforge3-Linux-aarch64.sh
wget https://github.com/conda-forge/miniforge/releases/latest/download/Miniforge3-Linux-aarch64.sh
bash Miniforge3-Linux-aarch64.sh -b  # Non-interactive install
validate_step "Miniforge installation"

# Initialize conda
echo "Initializing conda..."
~/miniforge3/bin/conda init bash
source ~/.bashrc || source ~/miniforge3/etc/profile.d/conda.sh
validate_step "Conda initialization"

# Create ROS2 Humble environment with RoboStack (incremental for memory-constrained Pi)
echo "Creating ROS2 Humble environment with RoboStack..."
echo "This will take several minutes on Pi Zero 2W (512MB RAM)..."

# Check if environment already exists
if [ -d ~/miniforge3/envs/ros_env ]; then
    echo "ROS2 environment already exists, skipping creation..."
else
    # Step 1: Create base environment with Python only
    echo "Step 1/5: Creating base Python environment..."
    ~/miniforge3/bin/mamba create -n ros_env -y python=3.10 -c conda-forge
    if [ $? -ne 0 ]; then
        echo "[FAIL] Failed to create base environment"
        exit 1
    fi
    echo "[OK] Base environment created"
    
    # Step 2: Install ROS2 base packages
    echo "Step 2/5: Installing ROS2 base (this may take 5-10 minutes)..."
    ~/miniforge3/bin/mamba install -n ros_env -y ros-humble-ros-base -c robostack-humble -c conda-forge
    if [ $? -ne 0 ]; then
        echo "[FAIL] Failed to install ROS2 base"
        exit 1
    fi
    echo "[OK] ROS2 base installed"
    
    # Step 3: Install CV bridge
    echo "Step 3/5: Installing cv_bridge..."
    ~/miniforge3/bin/mamba install -n ros_env -y ros-humble-cv-bridge -c robostack-humble -c conda-forge
    if [ $? -ne 0 ]; then
        echo "[FAIL] Failed to install cv_bridge"
        exit 1
    fi
    echo "[OK] cv_bridge installed"
    
    # Step 4: Install image transport
    echo "Step 4/5: Installing image_transport..."
    ~/miniforge3/bin/mamba install -n ros_env -y ros-humble-image-transport -c robostack-humble -c conda-forge
    if [ $? -ne 0 ]; then
        echo "[FAIL] Failed to install image_transport"
        exit 1
    fi
    echo "[OK] image_transport installed"
    
    # Step 5: Install colcon tools
    echo "Step 5/5: Installing colcon tools..."
    ~/miniforge3/bin/mamba install -n ros_env -y colcon-common-extensions -c conda-forge
    if [ $? -ne 0 ]; then
        echo "[FAIL] Failed to install colcon"
        exit 1
    fi
    echo "[OK] colcon installed"
fi

validate_step "ROS2 Humble environment creation"

# Verify ROS2 environment was created successfully
echo "Verifying ROS2 environment..."
if [ ! -d ~/miniforge3/envs/ros_env ]; then
    echo "[FAIL] ROS2 environment directory not found!"
    echo "Expected: ~/miniforge3/envs/ros_env"
    exit 1
fi

if [ ! -f ~/miniforge3/envs/ros_env/setup.bash ]; then
    echo "[WARNING] ROS2 setup.bash not found, environment may be incomplete"
    echo "Continuing anyway..."
fi
echo "[OK] ROS2 environment verified"

# Activate ROS2 environment and install additional Python packages
echo "Installing additional Python dependencies..."
source ~/miniforge3/bin/activate ros_env
pip install pyyaml opencv-python-headless numpy
validate_step "Python dependencies"

# Install camera-specific dependencies
if [ "$CAMERA_TYPE" = "ai" ]; then
    echo "Installing AI inference dependencies..."
    mamba install -y pytorch torchvision torchaudio cpuonly -c pytorch
    mamba install -y ultralytics -c conda-forge
    validate_step "AI dependencies"
fi

# Create ROS2 workspace if it doesn't exist
if [ ! -d ~/ros2_camera_ws ]; then
    echo "Creating ROS2 workspace..."
    mkdir -p ~/ros2_camera_ws/src
    cd ~/ros2_camera_ws
    source ~/miniforge3/envs/ros_env/setup.bash
    colcon build --symlink-install 2>/dev/null || true
    validate_step "ROS2 workspace creation"
fi

# Clone or copy project to workspace
PROJECT_SRC="$HOME/ros2_camera_ws/src/urc-Espresso-2026"
if [ ! -d "$PROJECT_SRC" ]; then
    echo "Setting up project in ROS2 workspace..."
    SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
    PROJECT_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"
    
    # Check if we found the project root correctly
    if [ -d "$PROJECT_ROOT/ros_nodes" ] && [ -d "$PROJECT_ROOT/configs" ]; then
        echo "Found project at: $PROJECT_ROOT"
        mkdir -p "$HOME/ros2_camera_ws/src"
        cp -r "$PROJECT_ROOT" "$HOME/ros2_camera_ws/src/urc-Espresso-2026"
        echo "[OK] Project files copied to workspace"
    else
        echo "[WARNING] Could not find project root automatically"
        echo "Please manually copy project files to: $HOME/ros2_camera_ws/src/urc-Espresso-2026"
        echo "Expected structure: ros_nodes/, configs/, calibrations/ directories"
        # Continue anyway - user might copy files later
    fi
    validate_step "Project setup"
else
    echo "Project already exists in workspace, skipping..."
fi

# Configure CycloneDDS for reliable WiFi operation
echo "Configuring CycloneDDS middleware..."
sudo mkdir -p /etc/cyclonedds
sudo tee /etc/cyclonedds/config.xml > /dev/null <<EOF
<?xml version="1.0" encoding="UTF-8"?>
<CycloneDDS xmlns="https://cdds.io/config" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="https://cdds.io/config https://raw.githubusercontent.com/eclipse-cyclonedds/cyclonedds/main/etc/cyclonedds.xsd">
  <Domain id="42">
    <General>
      <NetworkInterfaceAddress>auto</NetworkInterfaceAddress>
      <AllowMulticast>default</AllowMulticast>
      <MaxMessageSize>65536</MaxMessageSize>
    </General>
    <Discovery>
      <ParticipantIndex>auto</ParticipantIndex>
      <MaxAutoParticipantIndex>100</MaxAutoParticipantIndex>
      <SPDPDiscoverySockets>0</SPDPDiscoverySockets>
    </Discovery>
    <Internal>
      <LeaseDuration>10s</LeaseDuration>
    </Internal>
  </Domain>
</CycloneDDS>
EOF
validate_step "CycloneDDS configuration"

# Setup specific camera type
if [ "$CAMERA_TYPE" = "v20" ] || [ "$CAMERA_TYPE" = "v21" ]; then
    echo "Setting up for $CAMERA_TYPE camera (Pi #$PI_NUMBER)..."

    # Create systemd service file
    SERVICE_FILE="/etc/systemd/system/camera-publisher-pi$PI_NUMBER.service"
    sudo tee "$SERVICE_FILE" > /dev/null <<EOF
[Unit]
Description=Camera Publisher Pi $PI_NUMBER ($CAMERA_TYPE)
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=$USER
WorkingDirectory=$HOME/ros2_camera_ws
Environment="PYTHONUNBUFFERED=1"
Environment="ROS_DOMAIN_ID=42"
Environment="RMW_IMPLEMENTATION=rmw_cyclonedds_cpp"
Environment="CYCLONEDDS_URI=file:///etc/cyclonedds/config.xml"
Environment="PYTHONPATH=$HOME/ros2_camera_ws/src/urc-Espresso-2026"
Environment="CAMERA_TYPE=$CAMERA_TYPE"
ExecStart=/bin/bash -c 'source $HOME/miniforge3/bin/activate ros_env && source $HOME/miniforge3/envs/ros_env/setup.bash && exec python3 $HOME/ros2_camera_ws/src/urc-Espresso-2026/ros_nodes/cameras/pi_zero_2_w/camera_publisher/camera_publisher_node.py --pi-number $PI_NUMBER --camera-type $CAMERA_TYPE'
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF

    # Enable and start service
    sudo systemctl daemon-reload
    sudo systemctl enable "camera-publisher-pi$PI_NUMBER.service"
    
    echo "Camera publisher service installed for Pi #$PI_NUMBER with $CAMERA_TYPE camera"
    echo "Service will start automatically on next boot"
    validate_step "Camera publisher service setup"

elif [ "$CAMERA_TYPE" = "ai" ]; then
    echo "Setting up for AI camera with inference..."

    # Create systemd service file
    SERVICE_FILE="/etc/systemd/system/ai-camera-detector.service"
    sudo tee "$SERVICE_FILE" > /dev/null <<EOF
[Unit]
Description=AI Camera Detector
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=$USER
WorkingDirectory=$HOME/ros2_camera_ws
Environment="PYTHONUNBUFFERED=1"
Environment="ROS_DOMAIN_ID=42"
Environment="RMW_IMPLEMENTATION=rmw_cyclonedds_cpp"
Environment="CYCLONEDDS_URI=file:///etc/cyclonedds/config.xml"
Environment="PYTHONPATH=$HOME/ros2_camera_ws/src/urc-Espresso-2026"
ExecStart=/bin/bash -c 'source $HOME/miniforge3/bin/activate ros_env && source $HOME/miniforge3/envs/ros_env/setup.bash && exec python3 $HOME/ros2_camera_ws/src/urc-Espresso-2026/ros_nodes/cameras/pi_zero_2_w/ai_camera_publisher/ai_camera_detector_node.py'
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF

    # Enable and start service
    sudo systemctl daemon-reload
    sudo systemctl enable ai-camera-detector.service
    
    echo "AI camera detector service installed"
    echo "Service will start automatically on next boot"
    validate_step "AI camera detector service setup"

else
    echo "ERROR: Unknown camera type '$CAMERA_TYPE'"
    echo "Supported types: v20, v21, ai"
    exit 1
fi

# Set environment variables in bashrc
echo "Setting up environment variables..."
grep -q "ROS_DOMAIN_ID=42" ~/.bashrc || echo "export ROS_DOMAIN_ID=42" >> ~/.bashrc
grep -q "RMW_IMPLEMENTATION=rmw_cyclonedds_cpp" ~/.bashrc || echo "export RMW_IMPLEMENTATION=rmw_cyclonedds_cpp" >> ~/.bashrc
grep -q "CYCLONEDDS_URI" ~/.bashrc || echo "export CYCLONEDDS_URI=file:///etc/cyclonedds/config.xml" >> ~/.bashrc
grep -q "ros2_camera_ws/src/urc-Espresso-2026" ~/.bashrc || echo "export PYTHONPATH=\$HOME/ros2_camera_ws/src/urc-Espresso-2026:\$PYTHONPATH" >> ~/.bashrc

# Source ROS2 Humble in bashrc
grep -q "miniforge3/envs/ros_env/setup.bash" ~/.bashrc || echo "source ~/miniforge3/envs/ros_env/setup.bash" >> ~/.bashrc

validate_step "Environment variable setup"

# Set hostname for easy identification
if [ "$CAMERA_TYPE" = "v20" ] || [ "$CAMERA_TYPE" = "v21" ]; then
    sudo hostnamectl set-hostname "pi-camera-$CAMERA_TYPE-$PI_NUMBER"
elif [ "$CAMERA_TYPE" = "ai" ]; then
    sudo hostnamectl set-hostname "pi-ai-camera"
fi
validate_step "Hostname configuration"

# Check WiFi signal strength
echo "Checking WiFi connection..."
if command -v iwconfig &> /dev/null; then
    WIFI_QUALITY=$(iwconfig wlan0 2>/dev/null | grep -o "Link Quality=[0-9]*/[0-9]*" | cut -d'=' -f2)
    if [ ! -z "$WIFI_QUALITY" ]; then
        echo "[INFO] WiFi Signal: $WIFI_QUALITY"
    else
        echo "[WARNING] Could not detect WiFi signal strength"
    fi
fi

echo ""
echo "=========================================="
echo "Setup Complete!"
echo "=========================================="
echo ""
echo "Installation Summary:"
echo "  - Miniforge: $([ -d ~/miniforge3 ] && echo 'Installed' || echo 'NOT FOUND')"
echo "  - ROS2 env: $([ -d ~/miniforge3/envs/ros_env ] && echo 'Created' || echo 'NOT FOUND')"
echo "  - Workspace: $([ -d ~/ros2_camera_ws ] && echo 'Created' || echo 'NOT FOUND')"
echo "  - Project: $([ -d ~/ros2_camera_ws/src/urc-Espresso-2026 ] && echo 'Copied' || echo 'NOT FOUND')"
if [ "$CAMERA_TYPE" = "v20" ] || [ "$CAMERA_TYPE" = "v21" ]; then
    echo "  - Service: $([ -f /etc/systemd/system/camera-publisher-pi$PI_NUMBER.service ] && echo 'Installed' || echo 'NOT FOUND')"
elif [ "$CAMERA_TYPE" = "ai" ]; then
    echo "  - Service: $([ -f /etc/systemd/system/ai-camera-detector.service ] && echo 'Installed' || echo 'NOT FOUND')"
fi
echo ""
echo "IMPORTANT: REBOOT REQUIRED"
echo ""
echo "Next steps:"
echo "1. Reboot the Pi: sudo reboot now"
echo ""
echo "After reboot:"
if [ "$CAMERA_TYPE" = "v20" ] || [ "$CAMERA_TYPE" = "v21" ]; then
    echo "2. Check service status: systemctl status camera-publisher-pi$PI_NUMBER"
    echo "3. View logs: journalctl -u camera-publisher-pi$PI_NUMBER -f"
    echo "4. Test camera topic: ros2 topic list | grep camera"
elif [ "$CAMERA_TYPE" = "ai" ]; then
    echo "2. Check service status: systemctl status ai-camera-detector"
    echo "3. View logs: journalctl -u ai-camera-detector -f"
    echo "4. Test camera topics: ros2 topic list | grep camera"
fi
echo ""
echo "Configuration:"
echo "  - Hostname: $(hostname)"
echo "  - ROS Domain ID: 42"
echo "  - Middleware: CycloneDDS"
echo "  - Log file: $LOG_FILE"
echo ""
echo "To manually test ROS2:"
echo "  source ~/.bashrc"
echo "  ros2 topic list"
echo "=========================================="