"""
Benchmarking tools for ROS2 camera streaming performance
"""
